package org.delfos.mirth.utils;

public class MessageControllerException extends Exception {

}
